#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

int main() {

    // children process

    // declaring the 2 children
    int pipefd[2];
    pid_t pid1, pid2; // the declaration of the two children

    // creation of the pipe
    pipe(pipefd);

    pid1 = fork(); // fork 1 (child)

    // checks for child 1
    if (pid1 == 0) {
        close(pipefd[0]); // close the read end
        dup2(pipefd[1], 1); // redirects stdout to pipe
        execlp("ls", "ls", "-F", (char*)NULL); // this process executes the first child
    }

    pid2 = fork(); // fork 2 (child)

    // checks for child 2
    if (pid2 == 0) {
        close(pipefd[1]); // close the write end
        dup2(pipefd[0], 0); // edirect stdin from pipe 
        execlp("nl", "nl", (char*)NULL); // this process executes the second child
    }

    // parent process

    // closes both ends in parent
    close(pipefd[0]);
    close(pipefd[1]);

    // waits for the 2 children to end
    wait(NULL);
    wait(NULL);

    // message to mark end of parent process
    printf("Parent finished processing\n");
    return 0;

}